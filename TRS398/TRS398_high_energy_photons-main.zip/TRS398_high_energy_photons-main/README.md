# TRS398_high_energy_photons
Determination of absorbed dose to water in a high energy photon beam , according to TRS 398. A python program for performing calculation and documenting the determined absorbed dose and variation from baseline value according to TRS 398 worksheet. It reduces the calculation time and documentation time in busy centers with multiple LINAC's .  

Documentation will be available soon
